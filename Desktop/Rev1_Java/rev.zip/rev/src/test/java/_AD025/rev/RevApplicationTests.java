package _AD025.rev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevApplicationTests {

	@Test
	void contextLoads() {
	}

}
